package org.capstore.dao;

import java.util.List;

import org.capstore.pojo.Category;

public interface CategoryDao {

	public List<Category> getAllCategories();
}
