package org.capstore.controller;

import java.util.Map;

import javax.validation.Valid;

import org.capstore.domain.Merchant;
import org.capstore.service.MerchantService;
import org.capstore.service.MerchantServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MerchantController {

	

	@Autowired
	MerchantService merchantService=new MerchantServiceImpl();
	
	
	
	@RequestMapping("/merchant")
	public String showMerchantForm(Map<String, Object>maps){
		
		//SimpleDateFormat simpleDate=new SimpleDateFormat("dd-MMM-yyyy");
		maps.put("merchant1", new Merchant());
		
		
		
	  return "merchant";		
	}
	
	@RequestMapping(value={"/saveMerchant"},method=RequestMethod.POST)
	   public ModelAndView savemerchant(@Valid @ModelAttribute("merchant1") Merchant merchant,BindingResult result){
		
		
			System.out.println(merchant);
			/*productService.save(merchant);*/
			merchantService.saveMerchant(merchant);
		return new ModelAndView("redirect:merchant");
			/*return "redirect:merchant";*/
		
	   }
		
	@RequestMapping("/showMerchant")
	public String showAllMerchant(Map<String, Object>maps){
		
		maps.put("merchants", merchantService.getAllMerchants());		
	return "showMerchant";	
	}

	
	
}
