package org.capstore.service;

import java.util.List;

import org.capstore.dao.ProductDao;
import org.capstore.dao.ProductDaoImpl;
import org.capstore.domain.Brand;
import org.capstore.domain.Merchant;
import org.capstore.domain.Product;
import org.capstore.domain.Stock;
import org.capstore.domain.Sub_category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;

@Controller("productService")
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductDao productdao=new ProductDaoImpl();
	
	@Transactional
	public List<Brand> getAllBrands() {
		
		return productdao.getAllBrands();
	}

	

	@Transactional
	public List<Sub_category> getAllSub_category() {
		// TODO Auto-generated method stub
		return productdao.getAllSub_category();
	}

	@Transactional
	public List<Stock> getAllStock() {
		// TODO Auto-generated method stub
		return productdao.getAllStock();
	}

	@Transactional
	public void saveProduct(Product product) {
		// TODO Auto-generated method stub
		productdao.saveProduct(product);
		
	}

	@Transactional
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productdao.getAllProducts();
	}

}
