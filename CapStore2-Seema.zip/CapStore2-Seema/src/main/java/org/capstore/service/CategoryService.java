package org.capstore.service;

import java.util.List;

import org.capstore.domain.Category;

public interface CategoryService {

	
	public List<Category> getAllCategories();
}
