package org.capstore.dao;

import java.util.List;

import org.capstore.domain.Category;

public interface CategoryDao {

	public List<Category> getAllCategories();
}
